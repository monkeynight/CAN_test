#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define NUMBER_OF_EXAMPLES_train 3200
#define NUMBER_OF_EXAMPLES_test 800

int FEATURE = 40;
int X_train[NUMBER_OF_EXAMPLES_train][400];
int y_train[NUMBER_OF_EXAMPLES_train];

int X_test[NUMBER_OF_EXAMPLES_test][400];
int y_test[NUMBER_OF_EXAMPLES_test];

void read_file(void) {
   FILE * fp;
	char * line = NULL;
	size_t len = 0;

	const char *s = " ";
	char *token = NULL;

	fp = fopen("mfcc_40_10x.txt", "r");
	if (fp == NULL) {
		printf("Error opening\n");
		exit(EXIT_FAILURE);
	}

	for (int i = 0; i < NUMBER_OF_EXAMPLES_train; i++) {
		getline(&line, &len, fp);

		token = strtok(line, s);
		for (int j = 0; j < 40; j++) {
			X_train[i][j] = atoi(token);
			token=strtok(NULL,s);
		}
		y_train[i] = atoi(token);
	}

	fp = fopen("mfcc_40_10y.txt", "r");
	if (fp == NULL) {
		printf("Error opening\n");
		exit(EXIT_FAILURE);
	}

	for (int i = 0; i < NUMBER_OF_EXAMPLES_test; i++) {
		getline(&line, &len, fp);

		token = strtok(line, s);
		for (int j = 0; j < 40; j++) {
			X_test[i][j] = atoi(token);
			token=strtok(NULL,s);
		}
		y_test[i] = atoi(token);
	}
  

}



void write_file(void) {
    FILE *fp;
    fp = fopen("X.txt", "w");

    for (int i = 0; i < NUMBER_OF_EXAMPLES_train; i++) {
        int input1[FEATURE];
        int input[FEATURE * 10];

        for (int j = 0; j < FEATURE; j++) {
            input1[j] = X_train[i][j];
        }

        for (int m = 0; m < FEATURE; ++m) {
            int sign = (input1[m] < 0) ? 1 : 0;
            input[m * 10] = sign;
            input1[m] = abs(input1[m]);

            for (int n = 1; n <= 9; ++n) {
                input[m * 10 + n] = (input1[m] >> (9 - n)) & 1;
            }
        }

        for (int k = 0; k < FEATURE * 10; k++) {
            fprintf(fp, "%d ", input[k]);
        }
        fprintf(fp, "%d\n", y_train[i]);
    }
    fclose(fp);
}

int main(void) {
    read_file();

    write_file();

    return 0;
}








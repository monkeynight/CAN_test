#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define NUMBER_OF_EXAMPLES_train 10000
#define NUMBER_OF_EXAMPLES_test 2500
#define CLASSES 5
#define FEATURES 2660

#define CLAUSES 200
#define THRESHOLD 15

#define NUMBER_OF_STATES 100
#define BOOST_TRUE_POSITIVE_FEEDBACK 0

#define PREDICT 1
#define UPDATE 0

int X_train[NUMBER_OF_EXAMPLES_train][FEATURES];
int y_train[NUMBER_OF_EXAMPLES_train];

int X_test[NUMBER_OF_EXAMPLES_test][FEATURES];
int y_test[NUMBER_OF_EXAMPLES_test];
int w[CLASSES * CLAUSES * FEATURES * 2];
    int mc_tsetlin_machine[CLASSES][CLAUSES][FEATURES][2];
void read_file(void) {
   FILE * fp;
	char * line = NULL;
	size_t len = 0;

	const char *s = " ";
	char *token = NULL;

	fp = fopen("CAN_X.txt", "r");
	if (fp == NULL) {
		printf("Error opening\n");
		exit(EXIT_FAILURE);
	}

	for (int i = 0; i < NUMBER_OF_EXAMPLES_train; i++) {
		getline(&line, &len, fp);

		token = strtok(line, s);
		for (int j = 0; j < FEATURES; j++) {
			X_train[i][j] = atoi(token);
			token=strtok(NULL,s);
		}
		y_train[i] = atoi(token);


	}

	fp = fopen("CAN_Y.txt", "r");
	if (fp == NULL) {
		printf("Error opening\n");
		exit(EXIT_FAILURE);
	}

	for (int i = 0; i < NUMBER_OF_EXAMPLES_test; i++) {
		getline(&line, &len, fp);

		token = strtok(line, s);
		for (int j = 0; j < FEATURES; j++) {
			X_test[i][j] = atoi(token);
			token=strtok(NULL,s);
		}
		y_test[i] = atoi(token);
	}
    fp = fopen("CAN_flat.txt", "r");
	if (fp == NULL) {
		printf("Error opening\n");
		exit(EXIT_FAILURE);
	}
int i ;
	for ( i = 0; i < CLASSES*FEATURES*CLAUSES*2; i++) {
		getline(&line, &len, fp);

		token = strtok(line, s);
		 {
			w[i] = atoi(token);
			token=strtok(NULL,s);
		}
        

	}
    printf("i=%d\n",i);

}




static inline int action(int state)
{
    return state > NUMBER_OF_STATES;
}

static inline void calculate_clause_output(int ta_state[CLAUSES][FEATURES][2], int clause_output[CLAUSES], int Xi[], int predict)
{
    int j, k;
    int action_include, action_include_negated;
    int all_exclude;

    for (j = 0; j < CLAUSES; j++)
    {
        clause_output[j] = 1;
        all_exclude = 1;
        for (k = 0; k < FEATURES; k++)
        {
            action_include = action(ta_state[j][k][0]);
            action_include_negated = action(ta_state[j][k][1]);

            all_exclude = all_exclude && !(action_include == 1 || action_include_negated == 1);

            if ((action_include == 1 && Xi[k] == 0) || (action_include_negated == 1 && Xi[k] == 1))
            {
                clause_output[j] = 0;
                break;
            }
        }

        clause_output[j] = clause_output[j] && !(predict == PREDICT && all_exclude == 1);
        
    }
}

static inline int sum_up_class_votes(int clause_output[CLAUSES])
{
    int class_sum = 0;
    for (int j = 0; j < CLAUSES; j++)
    {

        int sign = 1 - 2 * (j & 1);
        class_sum += clause_output[j] * sign;

    }

    class_sum = (class_sum > THRESHOLD) ? THRESHOLD : class_sum;
    class_sum = (class_sum < -THRESHOLD) ? -THRESHOLD : class_sum;

    return class_sum;
}

int tm_score(int ta_state[CLAUSES][FEATURES][2], int Xi[])
{
    int clause_output[CLAUSES];
    calculate_clause_output(ta_state, clause_output, Xi, PREDICT);
    
      
    return sum_up_class_votes(clause_output);
}



int mc_tm_predict( int X[])
{
    int max_class = 0;
    int max_class_sum = tm_score(mc_tsetlin_machine[0], X);
  //  printf("1: %d \n",max_class_sum);
    for (int i = 1; i < CLASSES; i++)
    {

        int class_sum = tm_score(mc_tsetlin_machine[i], X);
        if (max_class_sum < class_sum)
        {
            max_class_sum = class_sum;
            max_class = i;
        }
     // printf("%d: %d \n",i,class_sum);
    }
  
    
    return max_class;
}











int main(void)
{	
	srand(time(NULL));

read_file();

 
  
    int input[FEATURES];
    int output;
    float   a = 0;
	    int index = 0;
	    for (int i = 0; i < CLASSES; ++i)
	    {
	        for (int j = 0; j < CLAUSES; ++j)
	        {
	            for (int k = 0; k < FEATURES; ++k)

	            {

	                mc_tsetlin_machine[i][j][k][0] = w[index++];
	                mc_tsetlin_machine[i][j][k][1] = w[index++];
	            }
	        }
            
            
            
	    }
      for(int i = 0;i < NUMBER_OF_EXAMPLES_train;i++){
        clock_t start_total = clock();
       for(int j = 0;j < FEATURES;j++){
        
             input[j] = X_train[i][j];
       
        

           
    
               
              
           }

        
        
        output = mc_tm_predict( input);
      clock_t end_total = clock();
		double time_used = ((double) (end_total - start_total)) / CLOCKS_PER_SEC;
     if(output == y_train[i])
         a++;
   //     printf("  TIME %f\n", time_used);
 //    printf("预测：%d  实际：%d \n",output,y_train[i]);
    
      }
printf("准确率是%f\n",a/NUMBER_OF_EXAMPLES_train);
    a = 0;
          for(int i = 0;i < NUMBER_OF_EXAMPLES_test;i++){
        clock_t start_total = clock();
       for(int j = 0;j < FEATURES;j++) {
        
             input[j] = X_test[i][j];
       
             
          
               
              
           }

        
        
        output = mc_tm_predict( input);
      clock_t end_total = clock();
		double time_used = ((double) (end_total - start_total)) / CLOCKS_PER_SEC;
     if(output == y_test[i])
         a++;
   //     printf("  TIME %f\n", time_used);
 //    printf("预测：%d  实际：%d \n",output,y_train[i]);
    
      }
printf("准确率是%f\n",a/NUMBER_OF_EXAMPLES_test);
	return 0;
}









